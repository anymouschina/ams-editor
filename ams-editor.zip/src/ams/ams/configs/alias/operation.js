// operations
export const FORM_SUBMIT = {
    submit: {
        type: 'button',
        label: '提交',
        props: {
            type: 'primary'
        }
    }
};
