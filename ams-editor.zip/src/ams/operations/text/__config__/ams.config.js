export const config = {
    BASE: 'CONFIG_OPERATION',
    type: {
        default: 'text'
    }
};

export const defaults = {};
