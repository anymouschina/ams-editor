export const config = {
    BASE: 'CONFIG_OPERATION',
    type: {
        default: 'reset'
    },
    event: {
        props: {
            disabled: true,
            placeholder: 'reset类型无效'
        }
    },
};

export const defaults = {};
