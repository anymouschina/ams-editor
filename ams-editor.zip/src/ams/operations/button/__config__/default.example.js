export default {
    type: 'component',
    options: {
        is: 'div'
    },
    operations: {
        button: {
            type: 'button',
            label: 'button'
        }
    }
};
