export const config = {
    BASE: 'CONFIG_OPERATION',
    type: {
        default: 'button'
    }
};

export const defaults = {};
