export const config = {
    BASE: 'CONFIG_FIELD',
    type: {
        default: 'html'
    },
    default: {
        type: 'html',
        props: {
            precisio: 2,
            step: 0.1
        }
    },
};

export const defaults = {};
