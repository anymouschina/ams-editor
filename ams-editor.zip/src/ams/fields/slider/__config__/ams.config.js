export const config = {
    BASE: 'CONFIG_FIELD',
    type: {
        default: 'slider'
    },
    default: {
        type: 'inputnumber'
    },
};

export const defaults = {};
