export const config = {
    BASE: 'CONFIG_FIELD',
    type: {
        default: 'timepicker'
    },
    default: {
        type: 'inputnumber',
        default: 1548404069000
    },
};

export const defaults = {};
