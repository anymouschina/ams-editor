export const config = {
    BASE: 'CONFIG_FIELD',
    type: {
        default: 'progress'
    },
    default: {
        type: 'inputnumber'
    },
};

export const defaults = {};
