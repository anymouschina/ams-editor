export const config = {
    BASE: 'CONFIG_FIELD',
    type: {
        default: 'inputnumber'
    },
    default: {
        type: 'inputnumber'
    },
};

export const defaults = {};
