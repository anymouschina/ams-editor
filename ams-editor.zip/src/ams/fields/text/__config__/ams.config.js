export const config = {
    BASE: 'CONFIG_FIELD',
    type: {
        default: 'text'
    }
};

export const defaults = {};
