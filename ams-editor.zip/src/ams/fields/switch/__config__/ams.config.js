export const config = {
    BASE: 'CONFIG_FIELD',
    type: {
        default: 'switch'
    }
};

export const defaults = {};
