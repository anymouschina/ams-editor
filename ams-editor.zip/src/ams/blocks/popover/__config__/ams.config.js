export const config = {
    BASE: 'CONFIG_BLOCK',
    type: {
        default: 'popover'
    },
    blocks: {
        fields: {
            value: {
                default: {
                }
            }
        }
    },
    data: {
    },
    options: {
        text: 'popover'
    },
};

export const defaults = {};
