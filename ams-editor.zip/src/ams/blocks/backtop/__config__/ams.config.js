export const config = {
    BASE: 'CONFIG_BLOCK',
    type: {
        default: 'backtop'
    },
    blocks: {},
    data: {},
    options: {},
};

export const defaults = {};
